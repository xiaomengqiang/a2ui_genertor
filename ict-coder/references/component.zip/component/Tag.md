# Tag
> id: string | component: "Tag" | props: object

## props (required: `value`)
- `value`: string | DataBinding — Defines the text content.
- `color?`: string | DataBinding — variant=solid: info | error | alert | warning | success | disabled; variant=filled: all enum values.
- `icon?`: string | DataBinding — Valid kebab-case Lucide icon matching the context (e.g., 'chevron-right')
- `size?`: "large" | "medium" | "small"
- `variant?`: "filled" | "solid" (default: "filled")
- `closable?`: boolean — Whether to display the delete icon.
- `closeIcon?`: string — When closable is set to true, the attribute takes effect,Valid kebab-case Lucide icon matching the context (e.g., 'chevron-right').
- `className?`: string — Tailwind CSS classes for the component.

------

# tag 标签使用规范

## Props

- `value`: string
- `color`: `success | processing | error | default | warning` | #HEX
- `variant`: `filled | solid | outlined`
- `size`: `large | medium | small`
- `icon`: string
- `closable`: boolean
- `closeIcon`: string

### 用途

用于分类、属性、轻量状态或筛选条件。

### 文案

- 标签文案应简短。
- 中文标签通常控制在 10 个字以内。
- 不要使用句子式标签。
- 长含义应改写为短标签，并在详情或 Tooltip 中解释。

### 类型

- 状态标签
- 分类标签
- 告警标签
- 彩色标签
- 可选择/筛选标签
- 可关闭标签
- 只读 Tag 用于展示属性、分类、环境、版本、状态等短信息。
- 可选 Tag 用于筛选条件或轻量选择。
- 可关闭 Tag 用于已选条件、已添加对象、可移除属性。

### 视觉规则

- Tag 是轻量信息标记，不是按钮、Badge、Alert 或表格主内容。
- Tag 必须保持小尺寸、低高度、短文案和稳定圆角，不得撑高表格行、卡片行或工具栏。
- 同一业务区域内 Tag 尺寸、圆角、字重和内边距必须一致。
- Tag 文案通常单行显示；过长时优先改写，其次截断或通过 Tooltip / 详情解释。
- Tag 不应承担主要操作，不要使用强阴影、渐变、发光、描边叠加或大面积填充制造强调。
- 在 Table 中使用 Tag 时，Tag 只能表达状态、分类或属性，不能替代表格列文本说明。

### 告警标签

告警标签是 Tag 中最高优先级的状态表达，用于异常、风险、阻塞、告警等级、设备/服务状态、任务失败等需要用户快速识别的状态信息。

使用规则：

- 告警标签必须使用语义色，不得使用随意彩色标签替代。
- 告警标签颜色必须来自状态 token：`error`、`critical`、`warning`、`success`、`info` 或对应 container token。
- 告警等级应按语义强度选择颜色：`error` 表示失败/阻塞/严重告警，`critical` 表示高风险/高紧急度，`warning` 表示提醒/潜在风险，`success` 表示正常/恢复/通过，`info` 表示信息/处理中。
- 告警标签必须配合明确文案，如“严重”“紧急”“异常”“离线”“失败”“告警”“恢复”“正常”，不要只用颜色表达含义。
- 同一页面内同一告警状态必须使用同一颜色和同一文案，不得同义多写。
- 表格中的告警标签应保持紧凑，不得让行高随机变化；必要说明放到 Tooltip、详情 Drawer 或告警详情页。
- 告警标签不要与 Badge 混用。Badge 表示数量或通知点，Tag 表示状态或属性。

不要：

- 不要用粉色、紫色、青色等分类色表达告警等级。
- 不要把告警标签当装饰色块使用。
- 不要让所有状态都使用高饱和告警色，只有需要用户判断风险或状态时才使用。
- 不要只显示“高/中/低”而没有业务上下文；必要时写成“高风险”“中风险”“低风险”。

### 彩色标签

彩色标签用于非告警场景的辅助识别或弱装饰，例如分类、类型、对象属性、环境、版本、资源组、业务域和筛选条件。彩色标签的重要性低于告警标签，不应抢占主要状态表达。

使用规则：

- 彩色标签仅用于分类和辅助识别，不用于表达错误、告警、阻塞、成功或风险等级。
- 彩色标签颜色应来自可控分类色或 accent token，不得自定义色值。
- 同一组分类标签需要建立稳定映射，例如同一类别始终使用同一颜色。
- 彩色标签数量应受控，单个区域内不要出现过多颜色；颜色过多时优先改为中性标签或文本分类。
- 装饰性彩色标签只能作为轻量视觉辅助，不能影响用户对主状态、主操作和告警信息的判断。

不要：

- 不要用彩色标签替代告警标签。
- 不要在密集表格中给每个普通属性都加彩色标签。
- 不要让彩色标签比主操作、告警标签或关键指标更醒目。

### 规则

- 语义色只在表达状态时使用。
- 分类色用于可控分类体系。
- 同一区域标签尺寸一致。
- closable tag 用于已选筛选或可移除条件。

### Do

- 状态标签使用 `color` 语义色，告警等级按语义强度选择。
- 分类标签使用可控分类色或 accent token，建立稳定映射。
- 同一业务区域内 Tag 尺寸、圆角、字重和内边距保持一致。
- 可关闭标签使用 `closable` 用于已选筛选或可移除条件。
- 告警标签配合明确文案，如“严重”“紧急”“异常”。
- Tag 文案简短，单行显示，过长时优先改写或截断。

### Don't

- 不要把 Tag 当主操作。
- 不要在一个区域使用过多彩色标签。
- 不要和 Badge 混用：Tag 标记内容，Badge 标记数量/通知。

------

# Tag 示例

## Example: Tag value path

```json
{
	"state": {
		"tagLabel": "magenta"
	},
	"rootId": "tagName",
	"elements": [
		{
			"id": "tagName",
			"component": "Tag",
			"props": {
				"value": {
					"path": "/tagLabel"
				},
				"color": "purple"
			}
		}
	]
}
```

## Example: Tag value with icon

```json
{
	"id": "infoIconTag",
	"component": "Tag",
	"props": {
		"value": "信息提示",
		"icon": "info",
		"color": "default",
	}
},
```

## Example: Tag close

```json
{
	"id": "tagClose",
	"component": "Tag",
	"props": {
		"value": "关闭标签",
		"closable": true,
		"closeIcon": "circle-x"
	}
}
```
