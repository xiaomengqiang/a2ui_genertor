# ScatterChart
> Scatter chart component for plotting relationships between two variables.
> id: string | component: "ScatterChart" | props: object

## props (required: `option`, `className`)
- `option`:
  - `data`: object | DataBinding — Core chart data source (required)
  - `yAxisTitle?`: string — MANDATORY: The visible title/label of the Y-axis. This must be a descriptive string (e.g., 'Revenue (USD)', 'Count').
  - `markPoint?`: object | DataBinding
  - `color?`: string[] | DataBinding — Stick to default color groups. Override only upon explicit user request.
- `className`: string — Tailwind CSS classes for the component. Mandatory: width (w-) and height (h-) classes must be explicitly defined.

------

# ScatterChart | 散点图 示例

The chart already includes a legend and does not require an additional one.

## Example: Basic Scatter Chart
- Data uses series name as key with arrays of point objects (`xAxis`, `yAxis`)
- `yAxisTitle` is the Y-axis visible label (required)

```json
{
  "id": "scatterChart",
  "component": "ScatterChart",
  "props": {
    "option": {
      "data": {
        "1990": [
            [28604, 77, 17096866, "Australia", 1990],
            [31163, 77.4, 27662440, "Canada", 1990],
            [60001, 68, 1154605773, "China", 1990]
        ],
        "2000": [
            [19349, 69.6, 147568552, "Russia", 2000],
            [10670, 67.3, 53994606, "Turkey", 2000],
            [26424, 75.7, 57110117, "United Kingdom", 2000]
        ],
        "2015": [
            [44056, 81.8, 23968976, "Australia", 2015],
            [43294, 81.7, 35939927, "Canada", 2015],
            [13334, 76.9, 1376048943, "China", 2015]
        ]
      },
    },
    "className": "h-16 w-full"
  }
}
```

## Optional Props (add to `option`)
- `"color": ["#2070F3", "#63b430"]` — custom scatter colors
- `"markPoint": { "data": [{ "type": "max", "name": "Max" }] }` — mark specific data points
