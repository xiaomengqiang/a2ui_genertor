# Icon
> MUST be a valid Lucide icon.
> id: string | component: "Icon" | props: object

## props (required: `name`)
- `name`: string | DataBinding — Valid kebab-case Lucide icon name that semantically represents the surrounding content and context.
- `color?`: "default" | "info" | "error" | "alert" | "warning" | "success" | "disabled" | "brand" | "rose" | "pink" | "purple" | "indigo" | "cyan" | "green" | DataBinding — Semantic hex color matching context.
- `shape?`: "outline" | "two-tone" | "square" | "circle" — Icon background shape with auto-tinted color.
- `className?`: string — Tailwind CSS classes for the component.Mandatory: width (w-) and height (h-) classes must be explicitly defined.

------

# Icon 图标使用规范

用于表达操作、导航、状态、类别或重点对象。

## 使用规则

- 使用开发组件，通过语义匹配的 `name` 调用图标，不得用文字、Emoji 或临时绘制图形替代。
- 功能、图标按钮和图标操作使用基础图标：浅色模式使用 `shape=outline`，深色模式使用 `shape=fill`。
- `shape=circle` 用于头像、产品类别、应用分类等场景；默认 24 × 24px，按容器适配，最大 60 × 60px。
- `shape=square` 用于卡片分类、大型功能模块、单对象详情或需要突出主体的场景，不用于普通操作。

## 尺寸

- 仅使用 12、14、16、20、24、32、36、40、48、60px，不得创建其他尺寸。
- 基础图标尺寸与相邻文字字号一致，例如 14px 文字使用 14px 图标。
- 独立图标按所在组件或容器选择上述尺寸，不得为增强视觉效果随意放大。

## 色彩

先判断图标是否表达明确的功能状态，再选择 `color`。功能语义优先于彩色，不得按页面配色覆盖。

### 语义色

- `default`：普通操作、导航、工具和辅助功能等不表达状态的中性图标。
- `info`：提示。
- `error`：错误告警或错误。
- `alert`：次级告警或次级错误。
- `warning`：提醒。
- `success`：成功。
- `disabled`：失效或不可用。

### 彩色

`brand`、`rose`、`pink`、`purple`、`indigo`、`cyan`、`green` 仅用于无功能状态语义的类别识别或视觉辅助。选择时保持页面协调，同一类别使用固定颜色。

`brand` 也是无功能语义的彩色，不用于主操作、选中、激活或任何状态表达。`green` 是绿色彩色，不等于 `success`；其他相近色相同理。

## Don't

- 不得用装饰性图标承载功能操作、跳转或链接。
- 不得用彩色覆盖提示、错误、告警、提醒、成功或失效等功能语义。
- 不得把 `brand` 当作主操作、选中或激活语义。
- 不得自行组合底色、描边或形状模拟 `circle`、`square` 或双色图标。
- 不得混用风格、线宽或视觉体量明显不一致的图标。

------

# Icon 示例

## Example: Icon basic

```json
{
	"id": "iconProcess",
	"component": "Icon",
	"props": {
		"name": "circle-check",
		"color": "success",
		"shape": "circle",
		"className": "w-6 h-6"
	}
}
```

## Example: Icon name path

```json
{
	"state": {
		"currentStatusIcon": "check"
	},
	"rootId": "iconStatus",
	"elements": [
		{
			"id": "iconStatus",
			"component": "Icon",
			"props": {
				"name": {
					"path": "/currentStatusIcon"
				},
				"color": "rose",
				"className": "w-6 h-6"
			}
		}
	]
}
```
